package boardGame;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class LinesOfActionGUI extends JFrame implements ActionListener {
		Board board;
		LinesOfAction test;
		JFrame frame;
		//JSlider;
	
		 String lnames[] = {"  8  ","  7  ","  6  ","  5  ","  4  ","  3  ","  2  ","  1  "};
		 String lnames2[] = {"         A     ","      B   ","    C  ","    D  ","    E  ","    F  ","    G  ","    H  " };
		 String m_names[]={"New Game", "Exit"}; 
		 String m_name2[]={"Blue Goes First","Red Goes First"};
		 
		
		 JLabel labels[],labels_top[],labels_right[],labels_bottom[];
		 JButton buttons[]; 
		 JMenuItem menuitems[],menu_item[];
		 
		 JButton button,button2;
		 
		 
		 JMenuBar bar = new JMenuBar();
		 
		 JMenu file = new JMenu("File");
		 JMenu select = new JMenu("Selction");
		 
		 JMenu filemenu = new JMenu("file1");
		
		 

	 private void setmenubar()
    {   
		 bar.add(file);
		 menuitems = new JMenuItem[m_names.length];
	        for (int i=0; i <m_names.length; i++) 
	        {
	            menuitems[i] = new JMenuItem(m_names[i]);
	            menuitems[i].addActionListener(this);
	            file.add(menuitems[i]);
	        }
	   
	     bar.add(select);
	     menu_item = new JMenuItem[m_name2.length];
	     for (int j=0;j<m_name2.length;j++){
	    	 menu_item[j] = new JMenuItem(m_name2[j]);
	    	 menu_item[j].addActionListener(this);
	    	 select.add(menu_item[j]);
	     }
	     
	     

    }
	 

		 
	 
	 public void setJpanel(){
		 test = new LinesOfAction();
		 frame = new JFrame();
		 board = new Board(test.ROWS, test.COLUMNS);
	     JPanel display = board.getJPanel();	     
	     add(display, BorderLayout.CENTER);
	     
	     display.setPreferredSize(new Dimension(300,300));
	     //setPreferredSize(new Dimension(640,480));
	     setVisible(true);
	     
	   
	        
	       
	 }//may use as initialize the game
	 public void addPieces(){
		 for(int i=1;i<7;i++){
	        	Piece redPiece = new RoundPiece();
	        	redPiece.place(board, 0, i);
	        }
	        for(int j=1;j<7;j++){
	        	Piece bluePiece = new RoundPiece(Color.BLUE);
	        	//Piece bluePiece = new RoundPiece();
	        	bluePiece.place(board, j, 0);
	        }
	        for(int i=1;i<7;i++){
	        	Piece redPiece = new RoundPiece();
	        	redPiece.place(board, 7, i);
	        }
	        for(int j=1;j<7;j++){
	        	Piece bluePiece = new RoundPiece(Color.BLUE);
	        	//Piece bluePiece = new RoundPiece();
	        	bluePiece.place(board, j, 7);
	        }
	 }
	 public LinesOfActionGUI()
	    {	
		    
	        super("Lines Of Action");
	        Container c = getContentPane();
	        setJMenuBar(bar);
	       
	       
	        pack();
	        setSize(640, 480);
	        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
	   
	        setmenubar();
	        
	       
	        
	        //North
	        JPanel npanel = new JPanel();
	        npanel.setBorder(BorderFactory.createLoweredBevelBorder());
	        npanel.setLayout(new GridLayout(1,0));
	        for (int i = 0;i<lnames2.length;i++){
	        	labels_top = new JLabel[lnames2.length];
	        	labels_top[i]= new JLabel (lnames2[i]);
	        	npanel.add(labels_top[i]);
	        }
	        c.add(npanel,BorderLayout.NORTH);
	        
	        
	        //west
	        JPanel wpanel = new JPanel();
	       
	        wpanel.setBorder(BorderFactory.createLoweredBevelBorder());
	        wpanel.setLayout(new GridLayout(lnames.length,1));
	        for (int i = 0;i<lnames.length;i++){
	        	labels = new JLabel[lnames.length];
	        	labels[i]= new JLabel (lnames[i]);
	        	wpanel.add(labels[i]);
	        }
	        c.add(wpanel,BorderLayout.WEST);
      
	        //east
	        JPanel epanel = new JPanel();
	        epanel.setBorder(BorderFactory.createLoweredBevelBorder());
	        epanel.setLayout(new GridLayout(lnames.length,10));
	        for (int i = 0;i<lnames.length;i++){
	        	labels_right = new JLabel[lnames.length];
	        	labels_right[i]= new JLabel (lnames[i]);
	        	epanel.add(labels_right[i]);
	        }
	        c.add(epanel,BorderLayout.EAST);
	        
	        //south-label
	        JPanel mmpanel = new JPanel();
	        c.add(mmpanel,BorderLayout.SOUTH);
	        JPanel lpanel = new JPanel();
	        lpanel.setBorder(BorderFactory.createLoweredBevelBorder());
	        lpanel.setLayout(new GridLayout(1,0));
	        for (int i = 0;i<lnames2.length;i++){
	        	labels_bottom = new JLabel[lnames2.length];
	        	labels_bottom[i]= new JLabel (lnames2[i]);
	        	lpanel.add(labels_bottom[i]);
	        }
	        mmpanel.setLayout(new BorderLayout());
	        mmpanel.add(lpanel,BorderLayout.NORTH);
	        
	        
	        
	        //south
	        JPanel spanel = new JPanel(); 
	        button = new JButton("Play");
	        button2 = new JButton("Stop");
	        spanel.add(button);
	        spanel.add(button2);
	        mmpanel.add(spanel,BorderLayout.SOUTH);
	        
	        show();
	        
	        setJpanel();
	        pack();
	        addPieces();
	        
	    }
	 public static void main (String[] args )
	    {
	        LinesOfActionGUI app = new LinesOfActionGUI();
	        
	        
	        app.setVisible(true);
	        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   
	    }
	    

}

	
